// ============================================================
// ANALYSIS MEMORY — Smart context management
// Keeps only last 10-20 analyses in memory
// Prevents token bloat and reduces costs
// ============================================================

import type { AnalysisRecord, AnalysisResult, Timeframe } from '@/types'

// ─── CONFIG ───────────────────────────────────────────────────

const MEMORY_CONFIG = {
  maxRecent: 20,          // Max analyses kept in memory
  cacheWindowMs: 300_000, // 5 min: identical chart = return cached result
  similarityThreshold: 3, // minutes: if same timeframe analyzed recently, warn user
}

// ─── IN-MEMORY STORE (server-side, per process) ───────────────

interface CachedAnalysis {
  hash: string
  result: AnalysisResult
  timeframe: Timeframe
  cachedAt: number
}

// Ring buffer — fixed size, oldest auto-dropped
class AnalysisRingBuffer {
  private buffer: CachedAnalysis[] = []
  private maxSize: number

  constructor(maxSize: number) {
    this.maxSize = maxSize
  }

  push(item: CachedAnalysis) {
    if (this.buffer.length >= this.maxSize) {
      this.buffer.shift() // Drop oldest
    }
    this.buffer.push(item)
  }

  find(hash: string): CachedAnalysis | null {
    return this.buffer.find(i => i.hash === hash) ?? null
  }

  recentByTimeframe(timeframe: Timeframe, withinMs: number): CachedAnalysis | null {
    const cutoff = Date.now() - withinMs
    return this.buffer
      .filter(i => i.timeframe === timeframe && i.cachedAt > cutoff)
      .at(-1) ?? null
  }

  size() { return this.buffer.length }
  clear() { this.buffer = [] }
}

// Singleton cache — persists for server process lifetime
const analysisCache = new AnalysisRingBuffer(MEMORY_CONFIG.maxRecent)

// ─── CACHE OPERATIONS ─────────────────────────────────────────

/**
 * Generate a lightweight hash from image data
 * Uses first + middle + last 500 chars — fast, good enough for deduplication
 */
export function hashImage(base64: string): string {
  const len = base64.length
  const sample = [
    base64.slice(0, 500),
    base64.slice(Math.floor(len / 2) - 250, Math.floor(len / 2) + 250),
    base64.slice(-500),
    len.toString(),
  ].join('|')

  // Simple djb2 hash
  let hash = 5381
  for (let i = 0; i < sample.length; i++) {
    hash = ((hash << 5) + hash) + sample.charCodeAt(i)
    hash = hash & hash // Convert to 32-bit int
  }
  return Math.abs(hash).toString(36)
}

export function getCachedResult(
  imageHash: string,
  timeframe: Timeframe
): { result: AnalysisResult; fromCache: true } | null {
  const cached = analysisCache.find(imageHash)
  if (!cached) return null

  const ageMs = Date.now() - cached.cachedAt
  if (ageMs > MEMORY_CONFIG.cacheWindowMs) return null // Expired

  console.log(`[Cache] HIT — returning cached result (${Math.round(ageMs / 1000)}s old)`)
  return { result: cached.result, fromCache: true }
}

export function cacheResult(
  imageHash: string,
  timeframe: Timeframe,
  result: AnalysisResult
): void {
  analysisCache.push({
    hash: imageHash,
    result,
    timeframe,
    cachedAt: Date.now(),
  })
  console.log(`[Cache] Stored. Buffer size: ${analysisCache.size()}/${MEMORY_CONFIG.maxRecent}`)
}

/**
 * Check if user analyzed same timeframe very recently
 * Returns warning if so — might be duplicate submission
 */
export function checkRecentDuplicate(timeframe: Timeframe): {
  isDuplicate: boolean
  message?: string
} {
  const recent = analysisCache.recentByTimeframe(timeframe, MEMORY_CONFIG.similarityThreshold * 60 * 1000)
  if (!recent) return { isDuplicate: false }

  const ageMin = Math.round((Date.now() - recent.cachedAt) / 60000)
  return {
    isDuplicate: true,
    message: `You analyzed a ${timeframe} chart ${ageMin} minute${ageMin !== 1 ? 's' : ''} ago. Are you sure this is a different chart?`,
  }
}

export function getCacheStats() {
  return {
    size: analysisCache.size(),
    maxSize: MEMORY_CONFIG.maxRecent,
    cacheWindowMinutes: MEMORY_CONFIG.cacheWindowMs / 60000,
  }
}

// ─── PROMPT CONTEXT TRIMMER ───────────────────────────────────

/**
 * For future multi-turn conversations:
 * Trims history to last N analyses to prevent token bloat
 * Never send full chat history to AI — only recent context
 */
export function trimAnalysisContext(
  records: AnalysisRecord[],
  maxItems = 10
): AnalysisRecord[] {
  if (records.length <= maxItems) return records

  // Keep only most recent N
  const trimmed = records.slice(-maxItems)
  console.log(`[Memory] Trimmed context: ${records.length} → ${trimmed.length} analyses`)
  return trimmed
}

/**
 * Build a concise context summary from recent analyses
 * Used to give AI awareness of recent readings without sending full history
 * Keeps tokens minimal — summary only, not full JSON
 */
export function buildContextSummary(records: AnalysisRecord[]): string {
  if (records.length === 0) return ''

  const recent = trimAnalysisContext(records, 5) // Max 5 for context
  const lines = recent
    .filter(r => r.result)
    .map(r => {
      const bias = r.result!.marketBias
      const conf = r.result!.confidence
      const setup = r.result!.tradeSetup.type
      const tf = r.timeframe
      const age = formatAge(r.created_at)
      return `• ${tf} (${age}): ${bias} bias, ${setup} setup, ${conf}% confidence`
    })

  if (lines.length === 0) return ''

  return `Recent analyses for context (do not repeat, just be aware):\n${lines.join('\n')}`
}

function formatAge(isoString: string): string {
  const diff = Date.now() - new Date(isoString).getTime()
  const mins = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  if (mins < 60) return `${mins}m ago`
  return `${hours}h ago`
}
