// ============================================================
// IMAGE OPTIMIZER — Reduces API costs through smart compression
// Target: under 512KB per image sent to OpenAI
// GPT-4o-mini charges by image size — smaller = cheaper
// ============================================================

export interface OptimizedImage {
  base64: string
  mimeType: 'image/jpeg' | 'image/webp'
  originalSizeKB: number
  optimizedSizeKB: number
  savingsPercent: number
}

const TARGET_SIZE_KB = 400  // Under OpenAI's 512KB tile threshold
const MAX_DIMENSION = 1120  // OpenAI optimal max dimension
const JPEG_QUALITY = 0.82   // High quality, big size reduction

/**
 * Compress and resize image before sending to OpenAI
 * Runs in browser — no server cost
 * Typical savings: 60–80%
 */
export async function optimizeChartImage(file: File): Promise<OptimizedImage> {
  const originalSizeKB = Math.round(file.size / 1024)
  const imageBitmap = await createImageBitmap(file)
  const { width, height } = imageBitmap

  const { newWidth, newHeight } = calculateDimensions(width, height)

  const canvas = document.createElement('canvas')
  canvas.width = newWidth
  canvas.height = newHeight
  const ctx = canvas.getContext('2d')!
  ctx.drawImage(imageBitmap, 0, 0, newWidth, newHeight)
  imageBitmap.close()

  // Try WebP first (better compression), fallback to JPEG
  let base64 = ''
  let mimeType: 'image/jpeg' | 'image/webp' = 'image/webp'

  try {
    base64 = await canvasToBase64(canvas, 'image/webp', JPEG_QUALITY)
    const sizeKB = Math.round((base64.length * 3) / 4 / 1024)
    if (sizeKB > TARGET_SIZE_KB) {
      base64 = await canvasToBase64(canvas, 'image/jpeg', JPEG_QUALITY)
      mimeType = 'image/jpeg'
    }
  } catch {
    base64 = await canvasToBase64(canvas, 'image/jpeg', JPEG_QUALITY)
    mimeType = 'image/jpeg'
  }

  const optimizedSizeKB = Math.round((base64.length * 3) / 4 / 1024)
  const savingsPercent = Math.round((1 - optimizedSizeKB / originalSizeKB) * 100)

  console.log(`[Optimizer] ${originalSizeKB}KB → ${optimizedSizeKB}KB (${savingsPercent}% saved)`)

  return { base64, mimeType, originalSizeKB, optimizedSizeKB, savingsPercent }
}

function calculateDimensions(width: number, height: number) {
  if (width <= MAX_DIMENSION && height <= MAX_DIMENSION) {
    return { newWidth: width, newHeight: height }
  }
  const ratio = Math.min(MAX_DIMENSION / width, MAX_DIMENSION / height)
  return {
    newWidth: Math.round(width * ratio),
    newHeight: Math.round(height * ratio),
  }
}

function canvasToBase64(canvas: HTMLCanvasElement, type: string, quality: number): Promise<string> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) return reject(new Error('Canvas toBlob failed'))
        const reader = new FileReader()
        reader.onload = () => resolve((reader.result as string).split(',')[1])
        reader.onerror = reject
        reader.readAsDataURL(blob)
      },
      type,
      quality
    )
  })
}

export function estimateAnalysisCost(imageSizeKB: number): {
  estimatedCostUSD: number
  tokensEstimate: number
} {
  const tiles = Math.ceil(imageSizeKB / 85)
  const imageTokens = 85 + tiles * 170
  const outputTokens = 800
  const totalTokens = imageTokens + outputTokens
  const cost = (imageTokens / 1_000_000) * 0.15 + (outputTokens / 1_000_000) * 0.60
  return {
    estimatedCostUSD: Math.round(cost * 10000) / 10000,
    tokensEstimate: totalTokens,
  }
}
