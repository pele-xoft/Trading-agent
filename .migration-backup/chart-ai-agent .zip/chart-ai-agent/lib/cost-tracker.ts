// ============================================================
// COST TRACKER — Real-time spend monitoring
// Tracks tokens used, estimates cost, enforces daily limits
// Prevents surprise bills
// ============================================================

interface UsageRecord {
  timestamp: number
  model: string
  inputTokens: number
  outputTokens: number
  estimatedCostUSD: number
  timeframe: string
}

interface DailyUsage {
  date: string
  totalCostUSD: number
  analysisCount: number
  records: UsageRecord[]
}

// Pricing per 1M tokens (May 2026 rates)
const PRICING = {
  'gpt-4o-mini': { input: 0.15, output: 0.60 },
  'gpt-4o':      { input: 5.00, output: 15.00 },
  'mock-mode':   { input: 0,    output: 0 },
} as const

// Daily spend limit — change this to your comfort level
const DAILY_LIMIT_USD = 2.00   // $2/day max — very conservative
const MONTHLY_LIMIT_USD = 10.00 // $10/month hard limit

// In-memory usage log (resets on server restart)
// For persistence, save to Supabase (Phase 2)
const usageLog: UsageRecord[] = []

// ─── TRACK USAGE ─────────────────────────────────────────────

export function trackUsage(params: {
  model: string
  inputTokens: number
  outputTokens: number
  timeframe: string
}): UsageRecord {
  const pricing = PRICING[params.model as keyof typeof PRICING] ?? PRICING['gpt-4o-mini']

  const estimatedCostUSD =
    (params.inputTokens / 1_000_000) * pricing.input +
    (params.outputTokens / 1_000_000) * pricing.output

  const record: UsageRecord = {
    timestamp: Date.now(),
    model: params.model,
    inputTokens: params.inputTokens,
    outputTokens: params.outputTokens,
    estimatedCostUSD: Math.round(estimatedCostUSD * 100000) / 100000,
    timeframe: params.timeframe,
  }

  usageLog.push(record)

  // Keep log bounded — last 500 records
  if (usageLog.length > 500) usageLog.shift()

  console.log(`[Cost] Analysis cost: $${record.estimatedCostUSD.toFixed(5)} | Daily total: $${getDailyTotal().toFixed(4)}`)

  return record
}

// ─── LIMIT CHECKS ─────────────────────────────────────────────

export function checkDailyLimit(): {
  allowed: boolean
  dailySpend: number
  remainingBudget: number
  message?: string
} {
  const dailySpend = getDailyTotal()
  const remainingBudget = DAILY_LIMIT_USD - dailySpend

  if (dailySpend >= DAILY_LIMIT_USD) {
    return {
      allowed: false,
      dailySpend,
      remainingBudget: 0,
      message: `Daily limit of $${DAILY_LIMIT_USD} reached. Resets at midnight UTC. Upgrade limit in lib/cost-tracker.ts`,
    }
  }

  return { allowed: true, dailySpend, remainingBudget }
}

export function checkMonthlyLimit(): { allowed: boolean; monthlySpend: number } {
  const monthlySpend = getMonthlyTotal()
  return {
    allowed: monthlySpend < MONTHLY_LIMIT_USD,
    monthlySpend,
  }
}

// ─── STATS ────────────────────────────────────────────────────

export function getDailyTotal(): number {
  const today = new Date().toISOString().slice(0, 10)
  return usageLog
    .filter(r => new Date(r.timestamp).toISOString().slice(0, 10) === today)
    .reduce((sum, r) => sum + r.estimatedCostUSD, 0)
}

export function getMonthlyTotal(): number {
  const month = new Date().toISOString().slice(0, 7)
  return usageLog
    .filter(r => new Date(r.timestamp).toISOString().slice(0, 7) === month)
    .reduce((sum, r) => sum + r.estimatedCostUSD, 0)
}

export function getUsageStats() {
  const daily = getDailyTotal()
  const monthly = getMonthlyTotal()
  const totalAnalyses = usageLog.length

  return {
    today: {
      spend: daily,
      limit: DAILY_LIMIT_USD,
      remaining: Math.max(0, DAILY_LIMIT_USD - daily),
      percentUsed: Math.round((daily / DAILY_LIMIT_USD) * 100),
      analysisCount: usageLog.filter(r =>
        new Date(r.timestamp).toISOString().slice(0, 10) ===
        new Date().toISOString().slice(0, 10)
      ).length,
    },
    month: {
      spend: monthly,
      limit: MONTHLY_LIMIT_USD,
      remaining: Math.max(0, MONTHLY_LIMIT_USD - monthly),
      percentUsed: Math.round((monthly / MONTHLY_LIMIT_USD) * 100),
    },
    total: {
      analyses: totalAnalyses,
      averageCostPerAnalysis: totalAnalyses > 0
        ? usageLog.reduce((s, r) => s + r.estimatedCostUSD, 0) / totalAnalyses
        : 0,
    },
  }
}
