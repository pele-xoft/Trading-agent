// GET /api/stats — Usage and cost dashboard
import { NextResponse } from 'next/server'
import { getUsageStats } from '@/lib/cost-tracker'
import { getCacheStats } from '@/lib/analysis-memory'
import { isMockMode } from '@/services/mock-analysis.service'

export async function GET() {
  return NextResponse.json({
    mode: isMockMode() ? 'mock' : 'live',
    usage: getUsageStats(),
    cache: getCacheStats(),
    limits: {
      daily: '$2.00',
      monthly: '$10.00',
      note: 'Adjust in lib/cost-tracker.ts',
    },
  })
}
