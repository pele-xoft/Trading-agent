// ============================================================
// AI SERVICE — GPT-4o-mini with full cost optimization
// - Image compression (client-side, before this is called)
// - Response caching (5 min window)
// - Token tracking
// - Daily spend limits
// - Mock mode when no API key
// ============================================================

import OpenAI from 'openai'
import type { AnalysisResult, AnalyzeRequest, Timeframe } from '@/types'
import { buildAnalysisPrompt, PROMPT_VERSION } from '@/prompts/prompt-builder'
import { hashImage, getCachedResult, cacheResult } from '@/lib/analysis-memory'
import { trackUsage, checkDailyLimit } from '@/lib/cost-tracker'
import { isMockMode, mockAnalyzeChart } from '@/services/mock-analysis.service'

// ─── CLIENT ───────────────────────────────────────────────────

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY ?? 'not-set',
})

export const AI_MODEL = process.env.OPENAI_MODEL ?? 'gpt-4o-mini'

// ─── MAIN FUNCTION ────────────────────────────────────────────

export async function analyzeChart(request: AnalyzeRequest): Promise<{
  result: AnalysisResult
  processingTimeMs: number
  promptVersion: string
  model: string
  fromCache?: boolean
}> {
  // 1. Mock mode — free testing
  if (isMockMode()) {
    console.log('[AI] Running in MOCK MODE — no API call made')
    const mock = await mockAnalyzeChart(request.timeframe)
    return mock
  }

  // 2. Check daily spend limit
  const limitCheck = checkDailyLimit()
  if (!limitCheck.allowed) {
    throw new Error(limitCheck.message ?? 'Daily spending limit reached')
  }

  // 3. Check cache — skip API call if same image analyzed recently
  const imageHash = hashImage(request.imageBase64)
  const cached = getCachedResult(imageHash, request.timeframe)
  if (cached) {
    return {
      result: cached.result,
      processingTimeMs: 0,
      promptVersion: PROMPT_VERSION,
      model: `${AI_MODEL}-cached`,
      fromCache: true,
    }
  }

  // 4. Call OpenAI
  const startTime = Date.now()

  const response = await openai.chat.completions.create({
    model: AI_MODEL,
    max_tokens: 1500,           // Capped — full analysis fits in 1200 tokens
    temperature: 0.1,           // Low = consistent JSON output
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: buildAnalysisPrompt(request.timeframe),
      },
      {
        role: 'user',
        content: [
          {
            type: 'image_url',
            image_url: {
              url: `data:${request.mimeType};base64,${request.imageBase64}`,
              detail: 'high',  // Reads indicator values accurately
            },
          },
          {
            type: 'text',
            text: buildUserMessage(request.timeframe, request.instrument),
          },
        ],
      },
    ],
  })

  const processingTimeMs = Date.now() - startTime
  const rawText = response.choices[0]?.message?.content ?? ''

  if (!rawText) throw new Error('OpenAI returned empty response')

  // 5. Track cost
  if (response.usage) {
    trackUsage({
      model: AI_MODEL,
      inputTokens: response.usage.prompt_tokens,
      outputTokens: response.usage.completion_tokens,
      timeframe: request.timeframe,
    })
  }

  // 6. Parse and validate
  const result = parseAnalysisResponse(rawText)

  // 7. Cache for 5 minutes
  cacheResult(imageHash, request.timeframe, result)

  return { result, processingTimeMs, promptVersion: PROMPT_VERSION, model: AI_MODEL }
}

// ─── USER MESSAGE ─────────────────────────────────────────────

function buildUserMessage(timeframe: Timeframe, instrument?: string): string {
  const inst = instrument ? ` of ${instrument}` : ''
  return `Analyze this ${timeframe} chart${inst}. Return complete technical analysis as JSON.

Read carefully:
- Fast MA (yellow) and slow MA (blue) — position relative to price and each other
- RSI oscillator value and zone
- Stochastic K and D line values
- Price structure: trend, swing highs/lows
- Key support and resistance levels

Estimate any unclear values conservatively. Add warnings for anything uncertain.`
}

// ─── PARSER ───────────────────────────────────────────────────

function parseAnalysisResponse(rawText: string): AnalysisResult {
  const cleaned = rawText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim()

  let parsed: unknown
  try {
    parsed = JSON.parse(cleaned)
  } catch {
    const match = cleaned.match(/\{[\s\S]*\}/)
    if (!match) throw new Error('No valid JSON in AI response')
    parsed = JSON.parse(match[0])
  }

  if (typeof parsed !== 'object' || parsed === null) {
    throw new Error('Analysis result is not an object')
  }

  const r = parsed as Record<string, unknown>
  const required = ['marketBias', 'structure', 'indicators', 'tradeSetup', 'confidence', 'reasoning']
  for (const field of required) {
    if (!(field in r)) throw new Error(`Missing field: ${field}`)
  }

  if (typeof r.confidence === 'number') {
    r.confidence = Math.max(0, Math.min(100, r.confidence))
  }
  if (!Array.isArray(r.warnings)) r.warnings = []
  if (!Array.isArray(r.invalidationConditions)) r.invalidationConditions = []
  if (!Array.isArray(r.confidenceFactors)) r.confidenceFactors = []

  return r as unknown as AnalysisResult
}

export async function checkAIHealth(): Promise<{ ok: boolean; mode: string }> {
  if (isMockMode()) return { ok: true, mode: 'mock' }
  try {
    await openai.chat.completions.create({
      model: AI_MODEL,
      max_tokens: 5,
      messages: [{ role: 'user', content: 'ping' }],
    })
    return { ok: true, mode: 'live' }
  } catch {
    return { ok: false, mode: 'error' }
  }
}
