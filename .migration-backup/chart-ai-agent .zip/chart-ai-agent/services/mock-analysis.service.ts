// ============================================================
// MOCK ANALYSIS SERVICE — Free testing without API credits
// Returns realistic fake data when OPENAI_API_KEY is not set
// or when NEXT_PUBLIC_MOCK_MODE=true
// ============================================================

import type { AnalysisResult, Timeframe } from '@/types'
import { PROMPT_VERSION } from '@/prompts/prompt-builder'

export const isMockMode = (): boolean => {
  return (
    !process.env.OPENAI_API_KEY ||
    process.env.OPENAI_API_KEY === 'sk-your-openai-key-here' ||
    process.env.NEXT_PUBLIC_MOCK_MODE === 'true'
  )
}

export async function mockAnalyzeChart(timeframe: Timeframe): Promise<{
  result: AnalysisResult
  processingTimeMs: number
  promptVersion: string
  model: string
}> {
  // Simulate realistic processing delay
  await new Promise(r => setTimeout(r, 1500 + Math.random() * 1000))

  const scenarios = ['bearish', 'bullish', 'neutral'] as const
  const scenario = scenarios[Math.floor(Math.random() * scenarios.length)]

  const result = scenario === 'bearish'
    ? mockBearishResult(timeframe)
    : scenario === 'bullish'
    ? mockBullishResult(timeframe)
    : mockNeutralResult(timeframe)

  return {
    result,
    processingTimeMs: Math.round(1500 + Math.random() * 1000),
    promptVersion: PROMPT_VERSION,
    model: 'mock-mode',
  }
}

// ─── MOCK SCENARIOS ───────────────────────────────────────────

function mockBearishResult(timeframe: Timeframe): AnalysisResult {
  return {
    marketBias: 'bearish',
    structure: {
      trend: 'downtrend',
      higherHighs: false,
      lowerLows: true,
      keyLevel: 4500,
      description: 'Clear downtrend structure with consistent lower highs and lower lows. Price has been making a series of lower highs since the recent peak.',
    },
    indicators: {
      movingAverages: {
        fastAboveSlow: false,
        priceAboveFast: false,
        priceAboveSlow: false,
        crossoverRecent: true,
        crossoverType: 'death',
        description: 'Death cross confirmed on this timeframe. Price is trading below both moving averages which are now sloping downward, confirming bearish momentum.',
      },
      rsi: {
        value: 38.5,
        zone: 'bearish',
        divergence: 'none',
        description: 'RSI at 38.5, firmly below the 50 midline. No divergence detected — momentum is aligned with price direction.',
      },
      stochastic: {
        kValue: 28.3,
        dValue: 32.1,
        zone: 'oversold',
        crossover: 'bearish',
        divergence: 'none',
        description: 'Stochastic entering oversold territory. K line below D line confirms bearish momentum. Watch for a dead-cat bounce from oversold levels.',
      },
    },
    supportResistance: {
      nearestSupport: 4480,
      nearestResistance: 4535,
      keyLevels: [4480, 4500, 4535, 4560],
      description: 'Key support at 4480 (previous swing low). Resistance at 4535 where the broken support now acts as resistance.',
    },
    momentum: {
      type: 'continuation',
      strength: 'moderate',
      description: 'Bearish momentum continuing with moderate strength. No signs of reversal yet.',
    },
    tradeSetup: {
      type: 'sell',
      rationale: 'Sell retracement into resistance. All indicators aligned bearish. Wait for price to retrace into 4527-4535 zone before entering.',
      entryZone: { low: 4527, high: 4535 },
      stopLoss: 4548,
      stopLossRationale: 'Above the fast MA and recent swing high. Invalidates bearish structure if breached.',
      takeProfits: [
        { level: 4500, label: 'TP1', rationale: 'Round number and recent swing low' },
        { level: 4480, label: 'TP2', rationale: 'Major support level' },
        { level: 4453, label: 'TP3', rationale: 'Daily chart support / measured move target' },
      ],
      riskRewardRatio: 2.4,
    },
    confidence: 68,
    confidenceFactors: [
      'Death cross confirmed on MAs',
      'Price below both MAs',
      'RSI below 50 — bearish momentum',
      'Lower highs and lower lows structure',
      'Stochastic bearish crossover',
    ],
    reasoning: `On the ${timeframe} chart, the market is in a clear downtrend. The death cross on the moving averages combined with price trading below both MAs confirms bearish bias. RSI at 38.5 shows bearish momentum without being dangerously oversold. The best setup is to wait for a retracement into the 4527–4535 resistance zone and sell there with a tight stop above 4548.`,
    invalidationConditions: [
      'Close above 4550 on this timeframe',
      'RSI reclaiming 50 and holding',
      'Golden cross forming on MAs',
      'Break of the most recent lower high',
    ],
    warnings: [
      '⚠ MOCK MODE — This is simulated data for UI testing only',
      'Stochastic is near oversold — short-term bounce possible before continuation',
      'Always confirm with higher timeframe bias before entering',
    ],
  }
}

function mockBullishResult(timeframe: Timeframe): AnalysisResult {
  return {
    marketBias: 'bullish',
    structure: {
      trend: 'uptrend',
      higherHighs: true,
      lowerLows: false,
      keyLevel: 4580,
      description: 'Bullish structure intact with higher highs and higher lows. Price respecting the ascending structure.',
    },
    indicators: {
      movingAverages: {
        fastAboveSlow: true,
        priceAboveFast: true,
        priceAboveSlow: true,
        crossoverRecent: false,
        crossoverType: 'none',
        description: 'Price above both MAs, fast MA above slow MA. Classic bullish alignment. MAs are sloping upward confirming trend strength.',
      },
      rsi: {
        value: 61.2,
        zone: 'bullish',
        divergence: 'none',
        description: 'RSI at 61.2, comfortably above 50. Bullish momentum without being overbought. Room to run higher.',
      },
      stochastic: {
        kValue: 68.4,
        dValue: 62.1,
        zone: 'neutral',
        crossover: 'bullish',
        divergence: 'none',
        description: 'Stochastic showing bullish crossover in neutral territory. K above D, pointing upward.',
      },
    },
    supportResistance: {
      nearestSupport: 4540,
      nearestResistance: 4600,
      keyLevels: [4520, 4540, 4580, 4600],
      description: 'Support at 4540 (previous resistance, now flipped). Next resistance at 4600 round number.',
    },
    momentum: {
      type: 'continuation',
      strength: 'strong',
      description: 'Strong bullish momentum with all indicators aligned. Continuation setup favored.',
    },
    tradeSetup: {
      type: 'buy',
      rationale: 'Buy pullback to support. Wait for price to pull back to the 4540–4550 zone where MAs and previous resistance converge.',
      entryZone: { low: 4540, high: 4552 },
      stopLoss: 4528,
      stopLossRationale: 'Below the key support zone and fast MA. Structure break if price trades here.',
      takeProfits: [
        { level: 4580, label: 'TP1', rationale: 'Recent swing high' },
        { level: 4600, label: 'TP2', rationale: 'Round number resistance' },
        { level: 4625, label: 'TP3', rationale: 'Measured move / extension target' },
      ],
      riskRewardRatio: 2.8,
    },
    confidence: 72,
    confidenceFactors: [
      'Price above both MAs — bullish alignment',
      'RSI above 50 with room to run',
      'Higher highs and higher lows structure',
      'Bullish stochastic crossover',
      'Strong momentum reading',
    ],
    reasoning: `The ${timeframe} chart shows a healthy uptrend with all indicators aligned bullishly. Price is above both moving averages, RSI is above 50, and the structure shows higher highs and higher lows. The best entry is a pullback to the 4540–4552 zone where the fast MA and previous resistance (now support) converge.`,
    invalidationConditions: [
      'Close below 4528 on this timeframe',
      'RSI dropping below 45',
      'Death cross formation on MAs',
      'Break of the most recent higher low',
    ],
    warnings: [
      '⚠ MOCK MODE — This is simulated data for UI testing only',
      'Wait for pullback to entry zone — chasing at current price offers poor R:R',
    ],
  }
}

function mockNeutralResult(timeframe: Timeframe): AnalysisResult {
  return {
    marketBias: 'neutral',
    structure: {
      trend: 'ranging',
      higherHighs: false,
      lowerLows: false,
      keyLevel: null,
      description: 'Price is consolidating in a range. No clear directional bias. Wait for breakout confirmation.',
    },
    indicators: {
      movingAverages: {
        fastAboveSlow: false,
        priceAboveFast: true,
        priceAboveSlow: false,
        crossoverRecent: false,
        crossoverType: 'none',
        description: 'MAs are flat and converging — consolidation signal. Price is weaving between the two MAs with no clear direction.',
      },
      rsi: {
        value: 51.8,
        zone: 'neutral',
        divergence: 'none',
        description: 'RSI at 51.8, hugging the 50 midline. No momentum in either direction.',
      },
      stochastic: {
        kValue: 52.1,
        dValue: 48.9,
        zone: 'neutral',
        crossover: 'none',
        divergence: 'none',
        description: 'Stochastic oscillating around midpoint with no clear signal.',
      },
    },
    supportResistance: {
      nearestSupport: 4505,
      nearestResistance: 4545,
      keyLevels: [4505, 4525, 4545],
      description: 'Trading in a 40-point range between 4505 support and 4545 resistance.',
    },
    momentum: {
      type: 'unclear',
      strength: 'weak',
      description: 'No clear momentum direction. Wait for range to resolve.',
    },
    tradeSetup: {
      type: 'wait',
      rationale: 'Market structure is unclear. Price is consolidating with no directional conviction from indicators. Wait for a breakout above 4545 or breakdown below 4505 with momentum confirmation before entering.',
      entryZone: { low: 0, high: 0 },
      stopLoss: 0,
      stopLossRationale: 'No setup — wait for confirmation',
      takeProfits: [
        { level: 4545, label: 'TP1', rationale: 'Range top — resistance' },
        { level: 4560, label: 'TP2', rationale: 'Above range breakout target' },
        { level: 4580, label: 'TP3', rationale: 'Extended breakout target' },
      ],
      riskRewardRatio: 0,
    },
    confidence: 25,
    confidenceFactors: [
      'MAs flat and converging — no trend',
      'RSI at midpoint — no momentum',
      'Range-bound price action',
    ],
    reasoning: `The ${timeframe} chart shows a consolidating market with no clear directional bias. All indicators are in neutral territory. This is a "wait" situation — entering here offers poor risk/reward. Watch for a breakout above 4545 with RSI moving above 55, or a breakdown below 4505 with RSI falling below 45.`,
    invalidationConditions: [
      'This setup has no trade — conditions change on breakout',
    ],
    warnings: [
      '⚠ MOCK MODE — This is simulated data for UI testing only',
      'No clear setup on this timeframe — patience is a position',
      'Check higher timeframes for overall bias direction',
    ],
  }
}
