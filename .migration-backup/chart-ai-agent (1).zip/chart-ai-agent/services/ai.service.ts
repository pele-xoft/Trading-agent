// ============================================================
// AI SERVICE — OpenAI GPT-4o mini (Vision)
// Cost-efficient, accurate chart reading
// ~$0.002–0.005 per analysis
// All AI calls flow through this file — never call directly
// ============================================================

import OpenAI from 'openai'
import type { AnalysisResult, AnalyzeRequest, Timeframe } from '@/types'
import { buildAnalysisPrompt, PROMPT_VERSION } from '@/prompts/prompt-builder'

// ─── CLIENT SETUP ────────────────────────────────────────────

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
})

// GPT-4o mini: best cost/accuracy ratio for vision tasks
// Switch to 'gpt-4o' for maximum accuracy (10x more expensive)
export const AI_MODEL = 'gpt-4o-mini'

// ─── MAIN ANALYSIS FUNCTION ──────────────────────────────────

export async function analyzeChart(request: AnalyzeRequest): Promise<{
  result: AnalysisResult
  processingTimeMs: number
  promptVersion: string
  model: string
}> {
  const startTime = Date.now()

  const systemPrompt = buildAnalysisPrompt(request.timeframe)
  const userMessage = buildUserMessage(request.timeframe, request.instrument)

  const response = await openai.chat.completions.create({
    model: AI_MODEL,
    max_tokens: 2048,
    temperature: 0.1,       // Low temp = consistent, structured output
    response_format: { type: 'json_object' }, // Force JSON output
    messages: [
      {
        role: 'system',
        content: systemPrompt,
      },
      {
        role: 'user',
        content: [
          {
            type: 'image_url',
            image_url: {
              url: `data:${request.mimeType};base64,${request.imageBase64}`,
              detail: 'high', // High detail = reads indicator values accurately
            },
          },
          {
            type: 'text',
            text: userMessage,
          },
        ],
      },
    ],
  })

  const processingTimeMs = Date.now() - startTime
  const rawText = response.choices[0]?.message?.content ?? ''

  if (!rawText) {
    throw new Error('GPT-4o mini returned empty response')
  }

  const result = parseAnalysisResponse(rawText)

  // Log token usage for cost tracking
  if (response.usage) {
    console.log(`[AI] Tokens used: ${response.usage.total_tokens} | Model: ${AI_MODEL}`)
  }

  return {
    result,
    processingTimeMs,
    promptVersion: PROMPT_VERSION,
    model: AI_MODEL,
  }
}

// ─── USER MESSAGE ─────────────────────────────────────────────

function buildUserMessage(timeframe: Timeframe, instrument?: string): string {
  const instrumentText = instrument ? ` of ${instrument}` : ''
  return `Analyze this ${timeframe} chart${instrumentText}.

Return your complete technical analysis as a JSON object matching the exact structure in your instructions.

Read carefully:
- The two moving averages (fast = yellow, slow = blue)
- The RSI oscillator (purple) and its current value
- The Stochastic oscillator (K and D lines) and current values
- Price structure: trend direction, key swing highs/lows
- Support and resistance levels where price has reacted

Be precise with price levels. If a value is hard to read exactly, estimate it conservatively and add a warning.`
}

// ─── RESPONSE PARSER ─────────────────────────────────────────

function parseAnalysisResponse(rawText: string): AnalysisResult {
  // Strip markdown fences if present (shouldn't happen with json_object mode)
  const cleaned = rawText
    .replace(/```json\n?/g, '')
    .replace(/```\n?/g, '')
    .trim()

  let parsed: unknown
  try {
    parsed = JSON.parse(cleaned)
  } catch {
    // Try extracting JSON object if surrounded by text
    const match = cleaned.match(/\{[\s\S]*\}/)
    if (!match) throw new Error('No valid JSON in AI response')
    parsed = JSON.parse(match[0])
  }

  return validateAnalysisResult(parsed)
}

function validateAnalysisResult(raw: unknown): AnalysisResult {
  if (typeof raw !== 'object' || raw === null) {
    throw new Error('Analysis result is not an object')
  }

  const r = raw as Record<string, unknown>

  const required = ['marketBias', 'structure', 'indicators', 'tradeSetup', 'confidence', 'reasoning']
  for (const field of required) {
    if (!(field in r)) {
      throw new Error(`Missing required field: ${field}`)
    }
  }

  // Clamp confidence 0–100
  if (typeof r.confidence === 'number') {
    r.confidence = Math.max(0, Math.min(100, r.confidence))
  }

  // Ensure arrays exist
  if (!Array.isArray(r.warnings)) r.warnings = []
  if (!Array.isArray(r.invalidationConditions)) r.invalidationConditions = []
  if (!Array.isArray(r.confidenceFactors)) r.confidenceFactors = []

  return r as unknown as AnalysisResult
}

// ─── MODEL SWITCHER ───────────────────────────────────────────
// Call this to upgrade to full GPT-4o for a single analysis
// Useful for complex multi-timeframe setups

export async function analyzeChartHighAccuracy(request: AnalyzeRequest) {
  const original = AI_MODEL
  // Temporarily use gpt-4o for this call
  const response = await openai.chat.completions.create({
    model: 'gpt-4o',           // Full GPT-4o: best accuracy, higher cost
    max_tokens: 2048,
    temperature: 0.1,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: buildAnalysisPrompt(request.timeframe) },
      {
        role: 'user',
        content: [
          {
            type: 'image_url',
            image_url: {
              url: `data:${request.mimeType};base64,${request.imageBase64}`,
              detail: 'high',
            },
          },
          { type: 'text', text: buildUserMessage(request.timeframe, request.instrument) },
        ],
      },
    ],
  })

  const rawText = response.choices[0]?.message?.content ?? ''
  return {
    result: parseAnalysisResponse(rawText),
    processingTimeMs: 0,
    promptVersion: PROMPT_VERSION,
    model: 'gpt-4o',
  }
}

// ─── HEALTH CHECK ─────────────────────────────────────────────

export async function checkAIHealth(): Promise<boolean> {
  try {
    const response = await openai.chat.completions.create({
      model: AI_MODEL,
      max_tokens: 5,
      messages: [{ role: 'user', content: 'ping' }],
    })
    return !!response.choices[0]?.message?.content
  } catch {
    return false
  }
}
